#
import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import LabelEncoder
#
from nltk import pos_tag
from nltk import word_tokenize

# setup pandas environment options
# display.expand_frame_repr() allows for the representation of dataframes to stretch across pages, wrapped over the
# full column vs row-wise.
# Source: https://pandas.pydata.org/pandas-docs/stable/user_guide/options.html
pd.set_option('expand_frame_repr', True)

# display.max_rows() and display.max_columns() sets the maximum number of rows and columns
# displayed when a frame is pretty-printed. Truncated lines are replaced by an ellipsis.
# Source: https://pandas.pydata.org/pandas-docs/stable/user_guide/options.html
pd.set_option("display.max_columns", 50)
pd.set_option("display.max_rows", 1000)


def make_environment():
    """
    this function merely does house cleaning in that it removes
    prior files and ensures that consistency in interim files and results\n
    :return: None
    :rtype: None
    """
    try:
        # make the folders you need for processing
        # this makes the 'data' folder in the current working directory
        os.mkdir(get_data_path())
        # make folder for keeping the input
        os.mkdir(get_data_path() + "/input_files")
        # folder for writing the output
        os.mkdir(get_data_path() + "/_cleaned")
        # following files are generated at different parts in the code
        # if prior copies exist, delete them to ensure consistency
        files_to_delete = ["the_files_features.csv",
                           "the_files_features_only.csv",
                           "the_files_numerical.csv",
                           "the_files_pos.csv",
                           "the_files_postagged_interim.csv",
                           "the_files_features_final.csv",
                           "the_files_target_only.csv"
                           ]
        for the_item in files_to_delete:
            # check for the existence of the files
            if os.path.exists(the_item):
                print(f"Deleting prior files, if any '{the_item}'")
                # remove the file, if it exists
                os.remove(the_item)
    except:
        # blank print() statement just silences the harmless 'except' clause
        print("")
    #
    return


def get_file_list(folder_param: str, file_spec_param: str) -> list:
    """
    this function finds the files of Python wildcard specification in a specified folder.
    It is useful to find any files in any folder but here it is used to find .txt files
    :param folder_param: folder where you want to search files
    :type folder_param:
    :param file_spec_param: Python wildcard specification for the searching the files
    :type file_spec_param:
    :return: list of all the files found in the folder you specify
    :rtype: list
    """
    # create a list with in all the files in the folder
    all_files_folders = os.listdir(folder_param)
    filtered_filenames = []
    for item in all_files_folders:
        str_item = str(item)
        if str_item.__contains__(file_spec_param):
            filtered_filenames.append(item)
    # send back the filenames that matched the search criterion
    if len(filtered_filenames) == 0:
        print(
                "Text file with extension .txt not found.\n"
                "Please copy '*.txt' files into the 'data/input_files' folder and try again.")
        # terminate
        exit(-1)
    else:
        return filtered_filenames


def get_data_path() -> str:
    """
    this function returns a custom path for this implementation
    if you want input and output to be at the same location
    then you can bypass the \\data\\ folder and forget about this function
    but like all traditions in machine learning tradition, we should keep
    the input and output separate.
    path symbols create problems in Windows so replace them with forward slashes,
    just makes it easier for UNIX world too
    :return:path to the data folder where input files are located
    :rtype: str
    """
    data_path = (os.getcwd() + "\\data\\").replace("\\", "/")
    return data_path


def get_file_text(the_filename: str) -> str:
    """
    this function takes a filename as argument and
    returns its content. Meant for text files hence
    "rt" parameter in the open() function
    :param the_filename: the filename for which to get the text
    :type the_file: str
    :return: contents of the file
    :rtype:
    """
    the_file = open(the_filename, mode = "rt")
    the_file = the_file.read()
    #
    return the_file


# please do not call this function if you want to use punctuations as features
def remove_punctuations(content_param: str, the_filename_param: str) -> str:
    """

    :param content_param:
    :type content_param:
    :param the_filename_param:
    :type the_filename_param:
    :return:
    :rtype:
    """
    cleaned_folder = destination_folder + "_cleaned/"
    # make a local copy of the incoming parameter as we are altering it
    content_param_copy = content_param.lower()
    file_delimiter = " "
    content_param_copy = content_param_copy.splitlines(keepends = False)
    content_param_copy = word_tokenize(content_param_copy.__str__())
    list_of_sent_param = content_param_copy
    schema_data = {"filecontent": list_of_sent_param}
    df = pd.DataFrame(schema_data)

    # check if the file exists
    if not os.path.exists("sb_golden_punctuations.txt"):
        print(
                "Application needs 'sb_golden_punctuations.txt' which is missing, terminating code. Please copy this file from Git and"
                " copy in the working directory and the try again.")
        exit(-1)
    # open the file that contains punctuations we want to remove
    some_file = open("sb_golden_punctuations.txt", "r")
    # standardize each line to lower case
    to_remove = some_file.readline().lower()
    to_remove = to_remove.split(file_delimiter)
    counter = 0
    while counter < to_remove.__len__():
        df = df[df.filecontent != to_remove[counter]]
        df.reindex()
        counter = counter + 1
    # form the expression of output folder
    cf = cleaned_folder + the_filename_param + "_punct_removed.csv"
    df.to_csv(cf, index = False)

    # take the string and not the dataframe from the df to clean illegal characters
    processed = df.to_string(index = False).replace(" ", "")

    # remove characters added by Pandas that prevent vectorization
    processed = processed.replace("\n", " ")
    processed = processed.replace("  ", " ")
    processed = processed.replace("'", "")
    #
    return processed


def generate_PoS_tags(content_param: str, filename_param: str):
    """

    :param content_param:
    :type content_param:
    :param filename_param:
    :type filename_param:
    :return:
    :rtype:
    """
    # Store local copies of the incoming parameters
    the_text = content_param
    file_name = filename_param
    # Clean the punctuations. This function is more or less same as the stop words
    # but I chose to keep them separate and enjoy the flexibility
    the_text = remove_punctuations(content_param = the_text, the_filename_param = file_name)

    # open the Penn PoS tagger file which is a simple list of PoS tags
    # you can choose to store them as list in the code itself but
    # is that a good idea? your call.
    #
    # create a Dataframe of the Penn PoS tags stored in a CSV file
    # Penn PoS tags are standard and you can easily search them on the Internet or a
    # linguistics books. Note that PoS tags per se do not usually appear in a grammar book
    # but parts of speech do.
    # check if the file exists
    if not os.path.exists("sb_golden_penn_pos_tags.csv"):
        print(
                "Application needs 'sb_golden_penn_pos_tags.csv' which is missing, terminating code. Please copy this file from Git and"
                " copy in the working directory and the try again.")
        exit(-1)
    df_tags = pd.read_csv("sb_golden_penn_pos_tags.csv")
    dict_tags = dict()
    # initialize the dictionary with features and count as Zero.
    # this is not about Python but about creating a consistent set of
    # features irrespective of the document. The side benefit is that features
    # are finite.
    for the_key in df_tags["pos_tag"]:
        dict_tags[the_key] = 0

    # add these PoS tags as schema
    # use NLTK parts of speech tagger
    # standardze the text to lower case to prevent case bias
    tagged_text = pos_tag(word_tokenize(the_text.lower()))
    # collect the tokens from the 'tagged_text'
    # store these tokens in the list for schema and values for a dataframe
    pos_string = []
    pos_token = []
    for the_tagged in tagged_text:
        # individual replace statements to show what is being cleaned
        s = str(the_tagged).replace("'", "")
        s = s.replace("\"", "")
        s = s.replace(")", "")
        s = s.replace("(", "")
        s = s.split(",")
        # append respective items to respective lists
        pos_token.append(s[1].rstrip(" ").lstrip(" "))
        pos_string.append(s[0].rstrip(" ").lstrip(" "))
    # setup a dictionary of lists for a dataframe
    ts = {"pos_token": pos_token, "pos_string": pos_string}
    df_file_tok_val = pd.DataFrame(ts)
    # Generate an interim CSV file to see how the tagging worked out
    df_file_tok_val.to_csv("the_files_postagged_interim.csv", index = False)

    # make a final dictionary that stores the grouped count of each PoS tag
    final_pos_dict = dict()

    # add filename field to use for join later
    final_pos_dict["filename"] = the_raw_file

    # loop through the values using the keys
    for the_pos_key in dict_tags.keys():
        condition = (df_file_tok_val["pos_token"] == the_pos_key)
        # fire the where clause to get counts, note the use of where() that resembles SQL
        # but follows a Pythonic approach especially == sign
        #
        # make a temporaray dataframe that stores the count of PoS tag
        temp_df = df_file_tok_val.where(condition)
        final_pos_dict[the_pos_key] = temp_df["pos_token"].count()

    # here comes the core of the story, the_final_pos.csv file that
    # houses the features of the document you provided
    file_for_pos_tags = "the_files_pos.csv"

    # file exists?
    if os.path.exists(file_for_pos_tags):
        file_pos_df = pd.read_csv(file_for_pos_tags)
        file_pos_df = file_pos_df.append(final_pos_dict, ignore_index = True)
        file_pos_df.to_csv(file_for_pos_tags, index = False)

    # file does not exist?
    if not os.path.exists(file_for_pos_tags):
        print(f"File {file_for_pos_tags} does not exist, creating it")
        file_pos_df = pd.DataFrame(columns = final_pos_dict.keys())
        file_pos_df = file_pos_df.append(final_pos_dict, ignore_index = True)
        file_pos_df.to_csv(file_for_pos_tags, index = False)
    #
    return


# ------------------------------------------------------------------
# ---------------------main block -----------------------------------------

# input_files is a folder to store your raw text files
# just keeps it neat and clean
print("Feature Generator for Text Files")
destination_folder = get_data_path() + "input_files/"
# do basic housekeeping
make_environment()
#
# lists to collect data
the_file_list = []
file_contents_list = []
file_vectorized_list = []

# get the input filenames from the folder
the_file_list = get_file_list(destination_folder, ".txt")
print(f"\n\nTotal files to process: {the_file_list.__len__()}\nin {destination_folder}")
print("Generating features from raw text ...")

# get each file and process it
file_cnt = len(the_file_list)
for the_raw_file in the_file_list:
    # get each file from the fully qualified path
    file_content = get_file_text(destination_folder + the_raw_file)
    print(f"\nProcessing: {the_raw_file}\t\t({the_file_list.index(the_raw_file) + 1} of {file_cnt} files)")
    print(f"Size: {os.stat(destination_folder + the_raw_file).st_size} characters in the file")
    # generate Parts of Speech tags that will are features of this document
    generate_PoS_tags(file_content, the_raw_file)

# make a schema for the CSV file of features, starting with just file names
# this will be used in a Join later
the_schema = {"filename": the_file_list}

# create a dataframe and write to a file with all the filenames
df_0 = pd.DataFrame(the_schema)
df_0.to_csv("the_files_features.csv", index = False)
# run a join to combine two files - one with filename and the other
# with contents of that file but with parts of speech generated
# key: filename
df1 = df_0
df2 = pd.read_csv("the_files_pos.csv")
df_final = df1.merge(df2, left_on = 'filename', right_on = 'filename')
df_final.reindex()
print(df_final.info())
#
lbl_encode = LabelEncoder()
print(f"Encoding labels into features")
# batch process feature encoding
for col in df_final.columns:
    print(f"Feature = '{col}' \t\t\tDatatype = {df_final[col].dtype}")
    # encoding for strings
    if df_final[col].dtype == "object":
        # Encode
        df_final[col] = lbl_encode.fit_transform(df_final[col])
    df_final.reindex()

print("Writing features")
df_final.to_csv("the_files_numerical.csv", index = False)
print("\n\nProcessing complete.")
